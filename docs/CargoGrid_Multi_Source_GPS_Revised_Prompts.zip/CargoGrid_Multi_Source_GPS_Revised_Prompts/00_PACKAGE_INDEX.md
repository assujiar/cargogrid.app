# CargoGrid Multi-Source GPS Revised Prompt Package

This package contains complete standalone revised prompts aligning CargoGrid Advanced TMS, Customer Portal, and Enterprise Integrations with:

- Driver Mobile GPS tracking;
- direct physical GPS tracking through an always-on CargoGrid GPS Gateway;
- third-party GPS platform integration;
- hybrid source arbitration;
- customer subscription entitlements;
- canonical Supabase/PostGIS telemetry projections;
- deferred physical-device testing when hardware is unavailable;
- conditional live third-party testing when provider access is unavailable.

## Files

- `219_ADVANCED_TMS_WMS_README_REVISED.md`
- `220_ADVANCED_TMS_WMS_WBS_RUNTIME_KICKOFF_PROMPT_REVISED.md`
- `222_DISPATCH_BOARD_PROMPT_REVISED.md`
- `223_FLEET_DRIVER_DEVICE_SIM_PROMPT_REVISED.md`
- `224_ROUTE_LOAD_PLANNING_PROMPT_REVISED.md`
- `225_FIRST_MIDDLE_LAST_MILE_ORCHESTRATION_PROMPT_REVISED.md`
- `226_MULTI_SOURCE_GPS_TELEMATICS_INTEGRATION_PROMPT_REVISED.md`
- `227_CAPACITY_UTILIZATION_PROMPT_REVISED.md`
- `228_ADVANCED_MILESTONE_EXCEPTION_PROMPT_REVISED.md`
- `243_HIGH_VOLUME_TMS_WMS_CONTROLS_PROMPT_REVISED.md`
- `245_ADVANCED_TMS_WMS_INTEGRATED_VERIFICATION_PROMPT_REVISED.md`
- `246_TMS_WMS_INTEGRITY_SECURITY_HARDENING_PROMPT_REVISED.md`
- `247_TMS_WMS_DOCUMENTATION_HANDOFF_PROMPT_REVISED.md`
- `248_ADVANCED_TMS_WMS_CLOSURE_VERIFICATION_PROMPT_REVISED.md`
- `305_CUSTOMER_PORTAL_TRACKING_PROMPT_REVISED.md`
- `306_CUSTOMER_PORTAL_SHIPMENT_MONITORING_PROMPT_REVISED.md`
- `343_MAPS_GPS_TELEMATICS_ENTERPRISE_INTEGRATIONS_PROMPT_REVISED.md`

## Mandatory test interpretation

- Physical GPS hardware-in-loop testing is deferred and non-blocking when protocol simulator, container, parser, ACK, buffering, outage and recovery evidence passes.
- Live third-party platform testing may be conditionally skipped when credentials/API/legal/commercial prerequisites are unavailable.
- Deterministic provider contract tests remain mandatory.
- No prompt may claim external live evidence that was not actually produced.
